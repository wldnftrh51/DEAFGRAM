document.addEventListener('DOMContentLoaded', function() {

    // Event listener untuk tombol Refresh
    document.getElementById('refreshButton').addEventListener('click', function() {
        location.reload();
    });

    // Fungsi untuk kembali ke halaman sebelumnya (deafTrans.html)
    window.goBack = function() {
        window.history.back();
    }
});
