document.addEventListener('DOMContentLoaded', function() {
    // Fungsi untuk fitur tombol voice
    const voiceButton = document.querySelector('.voice-button');
    let audioStream;

    voiceButton.addEventListener('click', function() {
        if (audioStream && audioStream.active) {
            // Hentikan stream audio jika sedang berjalan
            audioStream.getTracks().forEach(track => track.stop());
            audioStream = null;
            alert('Microphone stopped.');
        } else {
            // Akses mikrofon
            navigator.mediaDevices.getUserMedia({ audio: true })
                .then(function(stream) {
                    audioStream = stream;
                    alert('Microphone started. Click again to stop.');
                })
                .catch(function(err) {
                    console.error("Error accessing microphone: " + err);
                });
        }
    });

    // Fungsi untuk tombol fitur sign language
    document.querySelectorAll('.feature-button img').forEach(button => {
        button.addEventListener('click', function() {
            alert('Feature button clicked: ' + this.alt);
        });
    });

    // Event listeners untuk tombol navigasi
    document.getElementById('transButton').addEventListener('click', function() {
        navigateTo('deafTrans.html');
    });

    document.getElementById('talkButton').addEventListener('click', function() {
        navigateTo('deafTalk.html');
    });

    document.getElementById('homeButton').addEventListener('click', function() {
        navigateTo('deafHome.html');
    });

    document.getElementById('studButton').addEventListener('click', function() {
        navigateTo('deafStud.html');
    });

    // Event listener untuk tombol pencarian
    document.querySelector('.search-button').addEventListener('click', function() {
        navigateTo('deafTrans2.html'); // Ganti dengan nama file yang sesuai
    });

    // Event listener untuk tombol pencarian
    document.querySelector('.juru-button').addEventListener('click', function() {
        navigateTo('deafTrans3.html'); // Ganti dengan nama file yang sesuai
    });

    // Fungsi untuk navigasi ke halaman berdasarkan URL
    function navigateTo(url) {
        window.location.href = url;
    }

    // Event listener untuk tombol kamera
    const cameraButton = document.getElementById('cameraButton');
    const stopCameraButton = document.getElementById('stopCameraButton');
    const videoContainer = document.querySelector('.video-container');
    const videoStream = document.getElementById('cameraStream');
    let stream;

    cameraButton.addEventListener('click', function() {
        // Tampilkan elemen video
        videoContainer.style.display = 'flex';

        // Akses kamera
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(mediaStream) {
                stream = mediaStream;
                videoStream.srcObject = stream;
            })
            .catch(function(err) {
                console.error("Error accessing camera: " + err);
            });
    });

    stopCameraButton.addEventListener('click', function() {
        // Hentikan stream video
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        // Sembunyikan elemen video
        videoContainer.style.display = 'none';
        // Kembali ke halaman deafTrans
        navigateTo('deafTrans.html');
    });
});
