document.addEventListener('DOMContentLoaded', function() {
    function showTab(tabId) {
        const tabs = document.querySelectorAll('.tab-content');
        tabs.forEach(tab => {
            tab.style.display = tab.id === tabId ? 'block' : 'none';
        });

        const tabButtons = document.querySelectorAll('.tab');
        tabButtons.forEach(button => {
            button.classList.toggle('active', button.getAttribute('onclick').includes(tabId));
        });
    }

    showTab('postingan'); // Default tab to show

    document.querySelectorAll('.tab').forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('onclick').split("'")[1];
            showTab(tabId);
        });
    });
});

function goBack() {
    window.history.back();
}

function openSettings() {
    // Implement settings functionality here
    alert('Settings clicked!');
}
