document.addEventListener('DOMContentLoaded', function () {
    console.log('DOM fully loaded and parsed');
    
    // Event listener untuk tombol mulai
    const mulaiButton = document.getElementById('mulaiButton');
    if (mulaiButton) {
        mulaiButton.addEventListener('click', function () {
            console.log('Mulai button clicked');
            window.location.href = 'login.html'; // Ganti 'halaman-lain.html' dengan URL halaman tujuan
        });
    }

    // Event listener untuk form login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function (event) {
            event.preventDefault(); // Mencegah form dari submit default
            console.log('Login form submitted');

            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            console.log('Username:', username);
            console.log('Password:', password);

            // Validasi sederhana
            if (username === 'admin' && password === 'admin123') {
                console.log('Login successful');
                // Redirect ke halaman deafHome.html jika validasi berhasil
                window.location.href = 'deafHome.html';
            } else {
                console.log('Invalid username or password');
                alert('Invalid username or password');
            }
        });
    }

    // Event listener untuk navigasi sidebar
    // const links = document.querySelectorAll('.sidebar ul li a');
    // links.forEach(link => {
    //     link.addEventListener('click', function (event) {
    //         event.preventDefault();
    //         const targetUrl = this.getAttribute('href');
    //         console.log('Sidebar link clicked, redirecting to', targetUrl);
    //         window.location.href = targetUrl;
    //     });
    // });
});
