document.addEventListener('DOMContentLoaded', function() {
    // Fungsi untuk navigasi bawah
    const bottomNavButtons = document.querySelectorAll('.bottom-nav button');
    bottomNavButtons.forEach(button => {
        button.addEventListener('click', function() {
            alert('Navigasi bawah diklik!');
        });
    });
});
