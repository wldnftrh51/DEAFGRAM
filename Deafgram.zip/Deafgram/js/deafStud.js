document.addEventListener('DOMContentLoaded', function() {
    // Event listener untuk Minggu Pertama
    document.getElementById('abjad').addEventListener('click', function() {
        alert('Selamat Belajar');
    });

    document.getElementById('angka').addEventListener('click', function() {
        alert('Selamat Belajar');
    });

    document.getElementById('kuis1').addEventListener('click', function() {
        alert('Mulai Kuis Pertama');
    });

    // Event listener untuk Minggu Kedua
    document.getElementById('kata-sapaan').addEventListener('click', function() {
        alert('Selamat belajar');
    });

    document.getElementById('perkenalan').addEventListener('click', function() {
        alert('Selamat Belajar');
    });

    document.getElementById('kuis2').addEventListener('click', function() {
        alert('Mulai Kuis Kedua');
    });

    // Event listener untuk tombol Trans
    document.getElementById('transButton').addEventListener('click', function() {
        navigateTo('deafTrans.html');
    });

    // Event listener untuk tombol Talk
    document.getElementById('talkButton').addEventListener('click', function() {
        navigateTo('deafTalk.html');
    });

    // Event listener untuk tombol Home
    document.getElementById('homeButton').addEventListener('click', function() {
        navigateTo('deafHome.html');
    });

    // Event listener untuk tombol Stud
    document.getElementById('studButton').addEventListener('click', function() {
        navigateTo('deafStud.html');
    });

    // Fungsi untuk navigasi ke halaman berdasarkan URL
    function navigateTo(url) {
        window.location.href = url;
    }

    // Fungsi untuk kembali ke halaman sebelumnya
    window.goBack = function() {
        window.history.back();
    }
});
