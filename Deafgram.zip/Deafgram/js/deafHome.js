document.addEventListener('DOMContentLoaded', function() {
    // Event listener untuk tombol Trans
    document.getElementById('transButton').addEventListener('click', function() {
        navigateTo('deafTrans.html');
    });

    // Event listener untuk tombol Talk
    document.getElementById('talkButton').addEventListener('click', function() {
        navigateTo('deafTalk.html');
    });

    // Event listener untuk tombol Home
    document.getElementById('homeButton').addEventListener('click', function() {
        navigateTo('deafHome.html');
    });

    // Event listener untuk tombol Stud
    document.getElementById('studButton').addEventListener('click', function() {
        navigateTo('deafStud.html');
    });

    // Event listener untuk gambar profil
    document.getElementById('profileLink').addEventListener('click', function(event) {
        event.preventDefault(); // Mencegah tautan bawaan diikuti
        navigateTo('deafProfil.html');
    });

    // Fungsi untuk navigasi ke halaman berdasarkan URL
    function navigateTo(url) {
        window.location.href = url;
    }
});
